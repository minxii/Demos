package ncpc.widget.service;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

/**
 * 取込写真一覧更新サービス
 * Created by comjo-09-337 on 2018/11/27.
 */
public class PhotoRefreshService extends Service {

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("FlashAir:", "onHandleIntent");
        if (onUpdateListener != null) {
            Log.d("FlashAir:", "onUpdate");
            onUpdateListener.onUpdate();
        }

        return super.onStartCommand(intent, flags, startId);
    }


    @Override
    public IBinder onBind(Intent intent) {
        Log.d("FlashAir:", "onBind");
        return new MyBinder();
    }

    public class MyBinder extends Binder {
        public PhotoRefreshService getService() {
            return PhotoRefreshService.this;
        }
    }

    /**
     * 写真取込一覧更新用コールバック
     */
    public interface OnUpdateListener {
        void onUpdate();
    }

    private OnUpdateListener onUpdateListener;

    public void setOnUpdateListener(OnUpdateListener onUpdateListener) {
        this.onUpdateListener = onUpdateListener;
    }
}
