package ncpc.widget.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import ncpc.widget.R;
import ncpc.widget.dto.PhotoItem;

/**
 * 取込写真一覧Adapter
 * Created by comjo-09-337 on 2018/11/27.
 */

public abstract class PhotoAdapter<T> extends BaseAdapter {

    private int mLayoutRes;
    private ArrayList<T> mData;
    private boolean mSelectMode = false;
    public boolean mIsSelectAllFlg = false;

    public PhotoAdapter(ArrayList<T> mData, int mLayoutRes) {
        this.mData = mData;
        this.mLayoutRes = mLayoutRes;
    }

    public abstract void bindView(ViewHolder holder, T obj);

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public T getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = ViewHolder.bind(parent.getContext(), convertView, parent, mLayoutRes
                , position);
        bindView(holder, getItem(position));
        return holder.getItemView();
    }

    public boolean isSelectMode() {
        return mSelectMode;
    }

    public void setSelectMode(boolean mode) {
        mSelectMode = mode;

        if (mode) {

        } else {
            uncheckAll();
        }
    }

    public int getSelectedCount() {
        int cnt = 0;
        for (T data : mData) {
            if (((PhotoItem) data).isChecked()) {
                cnt++;
            }
        }
        return cnt;
    }

    public void checkAll() {
        for (T data : mData) {
            ((PhotoItem) data).setChecked(true);
        }

        mIsSelectAllFlg = true;
    }

    public void uncheckAll() {
        for (T data : mData) {
            ((PhotoItem) data).setChecked(false);
        }

        mIsSelectAllFlg = false;
    }

    public ArrayList<T> getData() {
        return mData;
    }

    public void setData(ArrayList<T> data) {
        mData = data;
    }

    /**
     * チェックボックスで選択された写真のパスを取得
     * @return
     */
    public ArrayList<String> getCheckedPhotoPath() {
        ArrayList<String> photoPathlist = new ArrayList<>();
        if (mData != null) {
            for (T t : mData) {
                if (((PhotoItem) t).isChecked()) {
                    photoPathlist.add(((PhotoItem) t).getPhotoPath());
                }
            }
        }

        return photoPathlist;
    }

    /**
     * アイテムを追加
     *
     * @param data
     */
    public void add(T data) {
        if (mData == null) {
            mData = new ArrayList<>();
        }
        mData.add(data);
        notifyDataSetChanged();
    }

    /**
     * 指定位置にアイテムを追加
     *
     * @param position
     * @param data
     */
    public void add(int position, T data) {
        if (mData == null) {
            mData = new ArrayList<>();
        }
        mData.add(position, data);
        notifyDataSetChanged();
    }

    /**
     * 指定アイテムを削除
     *
     * @param data
     */
    public void remove(T data) {
        if (mData != null) {
            mData.remove(data);
        }
        notifyDataSetChanged();
    }

    /**
     * 指定位置のアイテムを削除
     *
     * @param position
     */
    public void remove(int position) {
        if (mData != null) {
            mData.remove(position);
        }
        notifyDataSetChanged();
    }

    /**
     * 全てのアイテムをクリア
     */
    public void clear() {
        if (mData != null) {
            mData.clear();
        }
        notifyDataSetChanged();
    }


    public static class ViewHolder {

        private SparseArray<View> mViews;
        private View item;
        private int position;
        private Context context;

        private ViewHolder(Context context, ViewGroup parent, int layoutRes) {
            mViews = new SparseArray<>();
            this.context = context;
            View convertView = LayoutInflater.from(context).inflate(layoutRes, parent, false);
            convertView.setTag(this);
            item = convertView;
        }

        public static ViewHolder bind(Context context, View convertView, ViewGroup parent,
                                      int layoutRes, int position) {
            ViewHolder holder;
            if (convertView == null) {
                holder = new ViewHolder(context, parent, layoutRes);
            } else {
                holder = (ViewHolder) convertView.getTag();
                holder.item = convertView;
            }
            holder.position = position;
            return holder;
        }

        public <T extends View> T getView(int id) {
            T t = (T) mViews.get(id);
            if (t == null) {
                t = (T) item.findViewById(id);
                mViews.put(id, t);
            }
            return t;
        }

        public View getItemView() {
            return item;
        }

        public int getItemPosition() {
            return position;
        }

        public boolean isItemChecked() {
            CheckBox chkBox = getView(R.id.item_grid_image_chk);
            return chkBox.isChecked();
        }

        public void setItemChecked(boolean checked) {
            CheckBox chkBox = getView(R.id.item_grid_image_chk);
            ImageView tintView = getView(R.id.item_grid_image_tint);
            chkBox.setChecked(checked);
            if (checked) {
                tintView.setBackgroundColor(Color.parseColor("#3396dd96"));
            } else {
                tintView.setBackgroundColor(Color.parseColor("#00000000"));
            }
        }

        public void setStatus(boolean isSent) {
            TextView statusView = getView(R.id.item_grid_status_text);
            if (isSent) {
                statusView.setText(R.string.photo_status_sent);
                statusView.setTextColor(Color.parseColor("white"));
            } else {
                statusView.setText(R.string.photo_status_default);
                statusView.setTextColor(Color.parseColor("red"));
            }
        }

        public ViewHolder setText(int id, CharSequence text) {
            View view = getView(id);
            if (view instanceof TextView) {
                ((TextView) view).setText(text);
            }
            return this;
        }

        public ViewHolder setImageResource(int id, int drawableRes) {
            View view = getView(id);
            if (view instanceof ImageView) {
                ((ImageView) view).setImageResource(drawableRes);
            } else {
                view.setBackgroundResource(drawableRes);
            }
            return this;
        }

        public ViewHolder setBitmap(int id, Bitmap bm) {
            View view = getView(id);
            if (view instanceof ImageView) {
                ((ImageView) view).setImageBitmap(bm);
            }
            return this;
        }

        public ViewHolder setOnClickListener(int id, View.OnClickListener listener) {
            getView(id).setOnClickListener(listener);
            return this;
        }

        public ViewHolder setOnLongClickListener(int id, View.OnLongClickListener listener) {
            getView(id).setOnLongClickListener(listener);
            return this;
        }

        public ViewHolder setVisibility(int id, int visible) {
            getView(id).setVisibility(visible);
            return this;
        }

        public ViewHolder setTag(int id, Object obj) {
            getView(id).setTag(obj);
            return this;
        }
    }

}

