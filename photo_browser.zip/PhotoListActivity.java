package ncpc.widget.widget;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridView;

import java.io.File;
import java.util.ArrayList;

import ncpc.widget.R;
import ncpc.widget.common.NcpcUtil;
import ncpc.widget.dao.PhotoInfoDao;
import ncpc.widget.dto.PhotoDto;
import ncpc.widget.dto.PhotoItem;
import ncpc.widget.helper.PhotoDBHelper;
import ncpc.widget.receiver.PhotoDBChangeReceiver;
import ncpc.widget.service.PhotoRefreshService;

public class PhotoListActivity extends AppCompatActivity {

    private GridView grid_photo;
    private PhotoAdapter photoAdapter = null;
    private MenuItem btn_delete;
    private MenuItem btn_select_all;
    private ArrayList<PhotoItem> mData = null;
    private AlertDialog alert;

    private PhotoDBChangeReceiver mPhotoReceiver;
    private PhotoRefreshService mPhotoRefreshService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Toolbar矢印ボタン
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        grid_photo = (GridView) findViewById(R.id.grid_photo_list);

        initAdapter();

        grid_photo.setAdapter(photoAdapter);

        // ブロードキャストをレジスト
        registPhotoBr();

        // 写真更新サービスをバインディング
        Intent intent = new Intent(this, PhotoRefreshService.class);
        bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    public void onResume() {
        // クロム数を設定
        setNumCols();
        // 一覧最新化
        updateAdapter();
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mPhotoReceiver);
        unbindService(mServiceConnection);
        stopService(new Intent(this, PhotoRefreshService.class));
    }

    private void refreshUI() {
        if (photoAdapter != null) {
            photoAdapter.notifyDataSetChanged();
        }
    }

    private void OnSetSelectMode(boolean mode) {
        if (mode) {
            btn_delete.setVisible(true);
        } else {
            btn_delete.setVisible(false);
        }

        photoAdapter.setSelectMode(mode);
    }

    private void setNumCols() {
        int widthPx;
        int actWidth = grid_photo.getWidth();

        Log.d("FlashAir", "actWidth:" + actWidth);
        int windowWidth = this.getResources().getDisplayMetrics().widthPixels;
        Log.d("FlashAir", "windowWidth:" + windowWidth);


        if (actWidth <= 0 || actWidth == windowWidth) {
            widthPx = windowWidth;
        } else if ((windowWidth - actWidth) < 10) {
            widthPx = windowWidth;
        } else {
            widthPx = actWidth;
        }

        float scale = this.getResources().getDisplayMetrics().density;
        Log.d("FlashAir", "scale:" + scale);
        if (scale == 0) scale = 1;

        int widthDp = (int) (widthPx / scale + 0.5f);
        int cols = (int) Math.floor(widthDp / 160);
        Log.d("FlashAir", "width:" + widthDp);
        Log.d("FlashAir", "cols:" + cols);

        grid_photo.setNumColumns(cols);
    }

    /**
     * デフォルトbitmapアイコンを返却
     *
     * @return ic_launcher(Bitmap)
     */
    private Bitmap getDefaultBitmap() {
        return BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
    }

    private Bitmap getBitmapByFilePath(String path) {
        File f = new File(path);
        if (f.exists()) {
            return BitmapFactory.decodeFile(path);
        } else {
            return getDefaultBitmap();
        }
    }

    /**
     * 写真情報リスト取得
     * <p>
     * return List photoList
     */
    private ArrayList<PhotoDto> getPhotoList() {
        ArrayList<PhotoDto> photoList = new ArrayList<>();

        PhotoDBHelper helper = new PhotoDBHelper(this);
        // DBHelperオブジェクトの作成
        SQLiteDatabase db = null;
        try {
            // dbを開く
            db = helper.getReadableDatabase();

            // Daoにdbをセッティング
            PhotoInfoDao dao = new PhotoInfoDao(db);
            photoList = dao.getPhotoList();

        } catch (Exception e) {
            // ログ出力
            Log.e("FlashAir", "getPhotoList" + "[" + e.toString() + "]");
        } finally {
            if (db != null) db.close();
            helper.close();
        }

        return photoList;
    }

    /**
     * 写真のステータスを"削除済"にセット
     *
     * @param photoNm
     * @return
     */
    private boolean updatePhotoStatusToDel(String photoNm) {
        PhotoDBHelper helper = new PhotoDBHelper(this);
        // DBHelperオブジェクトの作成
        SQLiteDatabase db = null;
        try {
            // dbを開く
            db = helper.getReadableDatabase();

            // Daoにdbをセッティング
            PhotoInfoDao dao = new PhotoInfoDao(db);
            dao.updatePhotoStatusToDel(photoNm);
        } catch (Exception e) {
            // ログ出力
            Log.e("FlashAir", "updatePhotoStatusToDel" + "[" + e.toString() + "]");
            return false;
        } finally {
            if (db != null) db.close();
            helper.close();
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (photoAdapter.isSelectMode()) {
            OnSetSelectMode(false);
            refreshUI();
        } else {
            super.onBackPressed();
        }
    }

    /**
     * ToolBarとMenuをバインディング
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        btn_delete = menu.findItem(R.id.btn_delete);
        btn_select_all = menu.findItem(R.id.btn_select_all);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.btn_select_all:
                // User chose the "Favorite" action, mark the current item
                // as a favorite...
                if (photoAdapter.isSelectMode()) {
                    if (photoAdapter.mIsSelectAllFlg) {
                        OnSetSelectMode(false);
                    } else {
                        photoAdapter.checkAll();
                    }
                    refreshUI();
                } else {
                    OnSetSelectMode(true);
                    photoAdapter.checkAll();
                    refreshUI();
                }

                // すべて選択、選択をすべて解除のアイコンを切替え
                if (photoAdapter.mIsSelectAllFlg) {
                    btn_select_all.setIcon(R.drawable.photo_unselect_all);
                    btn_select_all.setTitle(R.string.title_menuitem_unselect_all);
                } else {
                    btn_select_all.setIcon(R.drawable.photo_select_all);
                    btn_select_all.setTitle(R.string.title_menuitem_select_all);
                }
                return true;
            case R.id.btn_delete:
                // User chose the "Favorite" action, mark the current item
                // as a favorite...
                final Activity act = this;
                alert = null;
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                alert = builder.setIcon(R.drawable.icon_warning)
                        .setTitle("メッセージ")
                        .setMessage("選択された写真をすべて削除します。よろしいですか？\n※　削除された写真は再度取込できません")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // 写真削除、DBフラグ設定
                                if (deletePhotos((ArrayList<PhotoItem>) photoAdapter.getData())) {
                                    alert.dismiss();
                                    // 写真選択モード解除
                                    OnSetSelectMode(false);
                                } else {
                                    AlertDialog.Builder ad = new AlertDialog.Builder(act);
                                    ad.setIcon(R.drawable.icon_error)
                                            .setTitle("写真削除エラー")
                                            .setMessage("写真削除にエラーが発生しました。")
                                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                }
                                            }).create();
                                    ad.show();
                                }

                                // 一覧更新
                                sendBrPhotoDBChanged();
                            }
                        })
                        .setNegativeButton("キャンセル", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                alert.dismiss();
                            }
                        }).create();
                alert.show();

                return true;
            case android.R.id.home:
                finish();
                return true;
            default:
                // If we got here, the user's action was not recognized. // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);
        }
    }

    /**
     * 選択された写真を削除する
     *
     * @param photoList
     * @return 削除処理結果
     */
    private boolean deletePhotos(ArrayList<PhotoItem> photoList) {
        ArrayList<PhotoItem> delList = new ArrayList<>();
        for (PhotoItem photo : photoList) {
            if (photo.isChecked()) {
                delList.add(photo);
            }
        }

        //選択された写真を削除
        try {
            for (PhotoItem delPhoto : delList) {
                String photoNm = getPhotoNmFromPath(delPhoto.getPhotoPath());
                Log.i("FlashAir", "【写真削除処理】photoName:" + photoNm);

                // 写真本体を削除
                File photoFile = new File(delPhoto.getPhotoPath());
                if (photoFile != null && photoFile.exists()) {
                    boolean r = photoFile.delete();
                    Log.d("FlashAir", "【写真本体削除】path:" + photoFile.getPath() +"【結果】：" + r);
                }
                // 写真サムネイルを削除
                File thumbFile = new File(delPhoto.getThumbPath());
                if (thumbFile != null && thumbFile.exists()) {
                    boolean r = thumbFile.delete();
                    Log.d("FlashAir", "【写真サムネイル削除】path:" + thumbFile.getPath() +"【結果】：" + r);
                }
                // DBに写真をステータスを"削除済"に
                boolean dbRes = updatePhotoStatusToDel(photoNm);
                Log.d("FlashAir", "【写真DB更新】【結果】：" + dbRes);
                // DB更新失敗の場合、falseをリターンする
                if (!dbRes) {
                    return false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("FlashAir", "取込写真一覧画面で写真削除処理にエラーが発生しました。");
            return false;
        }

        return true;
    }

    /**
     * 写真ファイルパスからDB検索用PhotoNmを取得
     *
     * @param path
     * @return photoNm
     */
    private String getPhotoNmFromPath(String path) {
        int index = path.lastIndexOf("/");
        return path.substring(index + 1);
    }

    private void initAdapter() {
        mData = new ArrayList<>();

        ArrayList<PhotoDto> photoList = getPhotoList();
        for (PhotoDto dto : photoList) {
            mData.add(new PhotoItem(dto.getThumbPath(), dto.getPhotoPath(), dto.getStatus()));
        }

        photoAdapter = new PhotoAdapter(mData, R.layout.photo_item) {
            @Override
            public void bindView(final ViewHolder holder, final Object obj) {
                final String photoPath = ((PhotoItem) obj).getPhotoPath();

                holder.setBitmap(R.id.item_grid_image, getBitmapByFilePath(((PhotoItem) obj).getThumbPath()));
                holder.setItemChecked(((PhotoItem) obj).isChecked());
                holder.setStatus(((PhotoItem) obj).isSent());
                if (photoAdapter.isSelectMode()) {
                    holder.setVisibility(R.id.item_grid_image_tint, View.VISIBLE);
                    holder.setVisibility(R.id.item_grid_image_chk, View.VISIBLE);
                } else {
                    holder.setVisibility(R.id.item_grid_image_tint, View.GONE);
                    holder.setVisibility(R.id.item_grid_image_chk, View.GONE);
                }

                holder.setOnClickListener(R.id.item_grid_image, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
//                        Intent intent = new Intent(PhotoListActivity.this, PhotoViewActivity.class);
//                        startActivity(intent);

                        Intent intent = new Intent();
                        File file = new File(photoPath);
                        intent.setAction(Intent.ACTION_VIEW);

                        intent.setDataAndType(Uri.fromFile(file), "image/*");
                        startActivity(intent);
                    }
                });

                holder.setOnClickListener(R.id.item_grid_image_tint, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean chk = !holder.isItemChecked();
                        ((PhotoItem) obj).setChecked(chk);
                        holder.setItemChecked(chk);

                        // 選択解除後選択している対象がない場合、選択モードを解除する
                        if (!chk && photoAdapter.getSelectedCount() == 0) {
                            OnSetSelectMode(false);
                        }
                        refreshUI();
                    }
                });

                holder.setOnLongClickListener(R.id.item_grid_image, new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        OnSetSelectMode(true);
                        ((PhotoItem) obj).setChecked(true);
                        holder.setItemChecked(true);
                        refreshUI();

                        return true;
                    }
                });

                holder.setOnLongClickListener(R.id.item_grid_image_tint, new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        boolean chk = !holder.isItemChecked();
                        ((PhotoItem) obj).setChecked(chk);
                        holder.setItemChecked(chk);

                        // 選択解除後選択している対象がない場合、選択モードを解除する
                        if (!chk && photoAdapter.getSelectedCount() == 0) {
                            OnSetSelectMode(false);
                        }
                        refreshUI();

                        return false;
                    }
                });
            }
        };
    }

    /**
     * 写真取込一覧最新化
     */
    private void updateAdapter() {
        mData = new ArrayList<>();

        ArrayList<PhotoDto> photoList = getPhotoList();
        for (PhotoDto dto : photoList) {
            mData.add(new PhotoItem(dto.getThumbPath(), dto.getPhotoPath(), dto.getStatus()));
        }

        // 選択モードの場合、各選択状態を保持
        if (photoAdapter.isSelectMode()) {
            ArrayList<String> photoPathList = photoAdapter.getCheckedPhotoPath();
            for (PhotoItem newPhoto : mData) {
                if(photoPathList.contains(newPhoto.getPhotoPath())) {
                    newPhoto.setChecked(true);
                }
            }
        }

        photoAdapter.setData(mData);
        refreshUI();
    }


    private void registPhotoBr() {
        mPhotoReceiver = new PhotoDBChangeReceiver();
        IntentFilter itFilter = new IntentFilter();
        itFilter.addAction("ncpc.widget.action.PHOTO_DB_CHANGED");
        registerReceiver(mPhotoReceiver, itFilter);
        Log.d("FlashAir:", "ブロードキャスト登録");
    }

    private void sendBrPhotoDBChanged() {
        sendBroadcast(new Intent("ncpc.widget.action.PHOTO_DB_CHANGED"));
    }

    ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            mPhotoRefreshService = ((PhotoRefreshService.MyBinder) iBinder).getService();

            mPhotoRefreshService.setOnUpdateListener(new PhotoRefreshService.OnUpdateListener() {
                @Override
                public void onUpdate() {
                    updateAdapter();
                }
            });
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {

        }
    };


}
