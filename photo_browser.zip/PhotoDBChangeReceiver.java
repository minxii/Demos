package ncpc.widget.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import ncpc.widget.service.PhotoRefreshService;

/**
 * 取込写真一覧更新通知用ブロードキャスト
 * Created by comjo-09-337 on 2018/11/27.
 */

public class PhotoDBChangeReceiver extends BroadcastReceiver {
    private final String ACTION_CHANGE = "ncpc.widget.action.PHOTO_DB_CHANGED";
    @Override
    public void onReceive(Context context, Intent intent) {
        if (ACTION_CHANGE.equals(intent.getAction())) {
            Log.d("FlashAir","onReceive(widget-写真削除)");
            context.startService(new Intent(context, PhotoRefreshService.class));
        }
    }
}
